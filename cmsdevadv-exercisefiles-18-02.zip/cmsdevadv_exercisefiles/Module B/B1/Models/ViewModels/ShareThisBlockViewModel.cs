﻿using AlloyAdvanced.Models.Blocks;

namespace AlloyAdvanced.Models.ViewModels
{
    public class ShareThisBlockViewModel
    {
        public ShareThisBlock Settings { get; set; }

        public string FriendlyUrl { get; set; }
    }
}