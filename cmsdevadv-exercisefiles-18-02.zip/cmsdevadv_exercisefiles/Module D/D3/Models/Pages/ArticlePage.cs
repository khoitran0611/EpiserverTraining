using EPiServer.Core;
using EPiServer.Web;
using System.ComponentModel.DataAnnotations;

namespace AlloyAdvanced.Models.Pages
{
    /// <summary>
    /// Used primarily for publishing news articles on the website
    /// </summary>
    [SiteContentType(
        GroupName = Global.GroupNames.News,
    [SiteImageUrl(Global.StaticGraphicsFolderPath + "page-type-thumbnail-article.png")]
    public class ArticlePage : StandardPage, IContentWithComments
    {
        //[SelectOne(SelectionFactoryType = typeof(ContactPageSelectionFactory))]
        [UIHint(Global.SiteUIHints.Contact)]
        public virtual PageReference Author { get; set; }
    }
}
