﻿using EPiServer.Framework;
using EPiServer.Framework.Initialization;
using System.Web.Mvc;
using System.Web.Routing;

namespace AlloyAdvanced.Business.Initialization
{
    [InitializableModule]
    [ModuleDependency(typeof(EPiServer.Web.InitializationModule))]
    public class IndexSiteContentInitializationModule
        : IInitializableModule
    {
        private bool initialized = false;

        public void Initialize(InitializationEngine context)
        {
            if (!initialized)
            {
                RouteTable.Routes.MapRoute(
                    name: "IndexSiteContent",
                    url: "indexsitecontent/{action}",
                    defaults: new { controller = "IndexSiteContent", action = "Index" });

                initialized = true;
            }
        }

        public void Uninitialize(InitializationEngine context) { }
    }
}