﻿using EPiServer.Core;
using EPiServer.Data.Dynamic;
using EPiServer.PlugIn;
using EPiServer.Search;
using EPiServer.ServiceLocation;
using System;
using System.Linq;
using System.Web.Mvc;

namespace AlloyAdvanced.Controllers
{
    [Authorize(Roles = "CmsAdmins")]
    [GuiPlugIn(
        Area = PlugInArea.AdminMenu,
        Url = "~/indexsitecontent",
        DisplayName = "Index Site Content")]
    public class IndexSiteContentController : Controller
    {
        public ActionResult Index(string startIndexing)
        {
            // indexing information is stored in DDS, so
            // we need to read the date of when
            // the last reindexing was executed.
            var indexings = Store.Items<IndexingInformation>();
            var mostRecent = indexings.OrderByDescending(
                i => i.ExecutionDate).FirstOrDefault();
            ViewBag.LastIndexing = mostRecent?.ExecutionDate;

            // is the admin clicks the Start Indexing button
            if (!string.IsNullOrWhiteSpace(startIndexing))
            {
                // execute a reindex
                ServiceLocator.Current.GetInstance
                    <IReIndexManager>().ReIndex();

                // save the date of when the reindex executed
                var information = new IndexingInformation
                {
                    ExecutionDate = DateTime.Now,
                    ResetIndex = true
                };
                Store.Save(information);
                ViewBag.LastIndexing = information.ExecutionDate;
            }

            return View();
        }

        private static DynamicDataStore Store
        {
            get
            {
                return (DynamicDataStoreFactory.Instance.GetStore(typeof(IndexingInformation)) ?? 
                    DynamicDataStoreFactory.Instance.CreateStore(typeof(IndexingInformation)));
            }
        }
    }
}