﻿using EPiServer.Shell.Search;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AlloyAdvanced.Business.SearchProviders
{
    [SearchProvider]
    public class AzureSearchProvider : ISearchProvider
    {
        public string Area => "CMS/pages";

        public string Category => "Azure Pages";

        public IEnumerable<SearchResult> Search(Query query)
        {
            string text = query.SearchQuery;

            var results = new List<SearchResult>();

            results.Add(new SearchResult(
                url: "https://www.apple.com/iphone/", 
                title: "iPhone", 
                previewText: $"Apple iPhone preview text, you searched for: \"{text}\"."));

            return results;
        }
    }
}