Free Commercial License from Yummygum
https://www.iconfinder.com/yummygum