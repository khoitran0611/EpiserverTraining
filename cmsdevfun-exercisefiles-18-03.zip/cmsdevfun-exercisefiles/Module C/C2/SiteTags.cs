﻿namespace AlloyTraining
{
    public static class SiteTags
    {
        public const string Full = "full";
        public const string Wide = "wide";
        public const string Narrow = "narrow";
    }
}