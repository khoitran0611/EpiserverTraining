﻿using AlloyTraining.Models.Blocks;

namespace AlloyTraining.Models.ViewModels
{
    public class TeaserBlockViewModel
    {
        public TeaserBlock CurrentBlock { get; set; }
        public int TodaysVisitorCount { get; set; }
    }
}